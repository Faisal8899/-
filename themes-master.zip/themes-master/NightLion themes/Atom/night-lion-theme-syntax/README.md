# night-lion-theme-syntax theme

Night Lion theme for ATOM editor (atom.io). This is still a work in progress. 


![A screenshot of your theme](https://f.cloud.github.com/assets/69169/2289498/4c3cb0ec-a009-11e3-8dbd-077ee11741e5.gif)
